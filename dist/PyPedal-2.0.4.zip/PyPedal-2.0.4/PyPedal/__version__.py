#!/usr/bin/env python

###############################################################################
# NAME: __version__.py
# VERSION: 2.0.0 (29SEPTEMBER2010)
# AUTHOR: John B. Cole, PhD (john.cole@ars.usda.gov)
# LICENSE: LGPL
###############################################################################

version = '2.0.4'

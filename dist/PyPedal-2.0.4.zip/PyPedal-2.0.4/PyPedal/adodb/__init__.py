#!/usr/bin/env python

from adodb import *
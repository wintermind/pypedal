#!/usr/bin/env python

###############################################################################
# NAME: __version__.py
# VERSION: 2.0.0a17 (13MAY2005)
# AUTHOR: John B. Cole, PhD (jcole@aipl.arsusda.gov)
# LICENSE: LGPL
###############################################################################

version = '2.0.0a17'
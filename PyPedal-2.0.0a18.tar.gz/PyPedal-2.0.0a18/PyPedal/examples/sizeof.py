#!/usr/bin/python

###############################################################################
# NAME: boichard.py
# VERSION: 2.0.0a3 (15APR2004)
# AUTHOR: John B. Cole, PhD (jcole@aipl.arsusda.gov)
# LICENSE: LGPL
###############################################################################

from pyp_classes import *
from pyp_io import *
from pyp_metrics import *
from pyp_nrm import *
from pyp_utils import *

try:
	from mx import Tools
except:
	print '[ERROR]: Could not load the mxTools module.  Halting!'
	import sys
	sys.exit(0)

if __name__=='__main__':

	print 'Starting pypedal.py at %s' % asctime(localtime(time()))
	print '\tPreprocessing pedigree at %s' % asctime(localtime(time()))
	example = preprocess('boichard2.ped',sepchar=' ')
	print '\t\tThe pedigree contains %s records' % (len(example))

	animal_size = 0
	print '\t\tAnimal() objects require %d bytes of memory' % (Tools.sizeof(example[0]))
	print '\t\t\tanimalID\t%d' % (Tools.sizeof(example[0].animalID))
	animal_size = animal_size + Tools.sizeof(example[0].animalID)
        print '\t\t\tsireID\t\t%d' % (Tools.sizeof(example[0].sireID))
        animal_size = animal_size + Tools.sizeof(example[0].sireID)
        print '\t\t\tdamID\t\t%d' % (Tools.sizeof(example[0].damID))
        animal_size = animal_size + Tools.sizeof(example[0].damID)
        print '\t\t\tgen\t\t%d' % (Tools.sizeof(example[0].gen))
        animal_size = animal_size + Tools.sizeof(example[0].gen)
        print '\t\t\tigen\t\t%d' % (Tools.sizeof(example[0].igen))
        animal_size = animal_size + Tools.sizeof(example[0].igen)
        print '\t\t\tby\t\t%d' % (Tools.sizeof(example[0].by))
        animal_size = animal_size + Tools.sizeof(example[0].by)
        print '\t\t\tsex\t\t%d' % (Tools.sizeof(example[0].sex))
        animal_size = animal_size + Tools.sizeof(example[0].sex)
        print '\t\t\tfa\t\t%d' % (Tools.sizeof(example[0].fa))
        animal_size = animal_size + Tools.sizeof(example[0].fa)
        print '\t\t\tfounder\t\t%d' % (Tools.sizeof(example[0].founder))
        animal_size = animal_size + Tools.sizeof(example[0].founder)
        print '\t\t\tancestor\t%d' % (Tools.sizeof(example[0].ancestor))
        animal_size = animal_size + Tools.sizeof(example[0].ancestor)
        print '\t\t\talleles\t\t%d' % (Tools.sizeof(example[0].alleles))
        animal_size = animal_size + Tools.sizeof(example[0].alleles)
        print '\t\t\trenumberedID\t%d' % (Tools.sizeof(example[0].renumberedID))
        animal_size = animal_size + Tools.sizeof(example[0].renumberedID)
        print '\t\t\tpedcomp\t\t%d' % (Tools.sizeof(example[0].pedcomp))
        animal_size = animal_size + Tools.sizeof(example[0].pedcomp)
        print '\t\t\tbreed\t\t%d' % (Tools.sizeof(example[0].breed))
        animal_size = animal_size + Tools.sizeof(example[0].breed)
        print '\t\t\tage\t\t%d' % (Tools.sizeof(example[0].age))
        animal_size = animal_size + Tools.sizeof(example[0].age)
        print '\t\t\talive\t\t%d' % (Tools.sizeof(example[0].alive))
        animal_size = animal_size + Tools.sizeof(example[0].alive)
	
	print '\t\t\tsons\t\t%d' % (Tools.sizeof(example[0].sons))
        animal_size = animal_size + Tools.sizeof(example[0].sons)
	print '\t\t\tdaus\t\t%d' % (Tools.sizeof(example[0].daus))
        animal_size = animal_size + Tools.sizeof(example[0].daus)
	print '\t\t\tunks\t\t%d' % (Tools.sizeof(example[0].unks))
        animal_size = animal_size + Tools.sizeof(example[0].unks)

	print '\t\tSub-Total\t\t%d' % (animal_size)
	print '\t\tTotal\t\t\t%d' % (animal_size*len(example))

	example = renumber(example,'example',io='yes')
	print '\tCalling set_ancestor_flag at %s' % asctime(localtime(time()))
	set_ancestor_flag(example,'example',io='yes')
	print '\tCollecting pedigree metadata at %s' % asctime(localtime(time()))
	example_meta = Pedigree(example,'example.ped','example_meta')
	print '\tCalling a_effective_founders_lacy() at %s' % asctime(localtime(time()))
	a_effective_founders_lacy(example,filetag='example')
	print '\tCalling a_effective_founders_boichard() at %s' % asctime(localtime(time()))
	a_effective_founders_boichard(example,filetag='example')
	print '\tCalling a_effective_ancestors_definite() at %s' % asctime(localtime(time()))
	a_effective_ancestors_definite(example,filetag='example')
	print '\tCalling a_effective_ancestors_indefinite() at %s' % asctime(localtime(time()))
	a_effective_ancestors_indefinite(example,filetag='example',n=10)

	#print '='*100
	#for e in example:
	#	e.printme()
	#example[0].printme()

	print 'Stopping pypedal.py at %s' % asctime(localtime(time()))

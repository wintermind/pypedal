#import PyPedal.pyp_newclasses as pyp_newclasses
#import PyPedal.pyp_nrm as pyp_nrm
#import PyPedal.pyp_metrics as pyp_metrics
import pyp_newclasses, pyp_nrm, pyp_metrics

options = {}
options['messages'] = 'verbose'
options['renumber'] = 1
options['pedfile'] = 'toller_nogender.ped'
#options['pedfile'] = 'jbc_nogender.ped'
options['pedformat'] = 'asd'
options['pedname'] = 'My Pedigree'
example = pyp_newclasses.NewPedigree(options)
example.load()
#my_b = pyp_nrm.inbreeding(example.pedigree,filetag='test_nogender')
#print my_b

#example.save(filename='toller_nogender_original_oid.ped',outformat='l',idformat='o')
#example.save(filename='toller_nogender_original_rid.ped',outformat='o',idformat='r')

#!/usr/bin/python

###############################################################################
# NAME: generations.py
# VERSION: 2.0.0a9 (23FEB2005)
# AUTHOR: John B. Cole, PhD (jcole@aipl.arsusda.gov)
# LICENSE: LGPL
###############################################################################

from pyp_classes import *
from pyp_io import *
from pyp_metrics import *
from pyp_nrm import *
from pyp_utils import *

if __name__=='__main__':

    print 'Starting pypedal.py at %s' % asctime(localtime(time()))
    print '\tLoading pedigree at %s' % asctime(localtime(time()))
    example,example_meta = load_pedigree('boichard2mod2.ped',sepchar=' ', \
        debug=1,io='no',renum=1,outformat='0',name='Pedigree Metadata', \
        alleles=0,progress=0)
    #example = preprocess('boichard2mod.ped',sepchar=' ')
    print '\t\tThe pedigree contains %s records' % (len(example))
    example = renumber(example,'example',io='yes')
    print '\tCalling set_ancestor_flag at %s' % asctime(localtime(time()))
    set_ancestor_flag(example,'example',io='yes')
    print '\tCalling assign_sexes at %s' % asctime(localtime(time()))
    assign_sexes(example)
    print '\tCollecting pedigree metadata at %s' % asctime(localtime(time()))
    example_meta = Pedigree(example,'example.ped','example_meta')
    #print '\tCalling a_effective_founders_lacy() at %s' % asctime(localtime(time()))
    #a_effective_founders_lacy(example,filetag='example')
    #print '\tCalling a_effective_founders_boichard() at %s' % asctime(localtime(time()))
    #a_effective_founders_boichard(example,filetag='example')
    #print '\tCalling a_effective_ancestors_definite() at %s' % asctime(localtime(time()))
    #a_effective_ancestors_definite(example,filetag='example')
    #print '\tCalling a_effective_ancestors_indefinite() at %s' % asctime(localtime(time()))
    #a_effective_ancestors_indefinite(example,filetag='example',n=10)

    print '\tCalling generation_lengths() at %s' % asctime(localtime(time()))
    generation_lengths(example,filetag='example',debug=0)
    print '\tCalling generation_lengths_all() at %s' % asctime(localtime(time()))
    generation_lengths_all(example,filetag='example',debug=1)

    print 'Stopping pypedal.py at %s' % asctime(localtime(time()))

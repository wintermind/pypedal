#!/usr/bin/python

###############################################################################
# NAME: descendants.py
# VERSION: 2.0.0a9 (29MAR2005)
# AUTHOR: John B. Cole, PhD (jcole@aipl.arsusda.gov)
# LICENSE: LGPL
###############################################################################

import pyp_newclasses
import pyp_nrm
import pyp_metrics
import time

options = {}
options['pedfile'] = 'descendants.ped'
options['pedformat'] = 'asd'
options['pedname'] = 'Descendants Pedigree'
options['messages'] = 'verbose'
options['renumber'] = 0
options['counter'] = 5

if __name__ == '__main__':

    print 'Starting pypedal.py at %s' % time.asctime(time.localtime(time.time()))
    
    example = pyp_newclasses.NewPedigree(options)
    example.load()
    print 'ID map: %s' % (example.idmap)
    
    if example.kw['messages'] == 'verbose':
        print '[INFO]: Calling pyp_metrics.descendants at %s' % (time.asctime(time.localtime(time.time())))
    founder_peds = pyp_metrics.founder_descendants(example)
    print founder_peds
    
    print 'Stopping pypedal.py at %s' % time.asctime(time.localtime(time.time()))
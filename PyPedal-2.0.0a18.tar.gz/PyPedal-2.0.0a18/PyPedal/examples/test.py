#import PyPedal.pyp_newclasses as pyp_newclasses
#import PyPedal.pyp_nrm as pyp_nrm
#import PyPedal.pyp_metrics as pyp_metrics
import pyp_newclasses, pyp_nrm, pyp_metrics

options = {}
options['messages'] = 'verbose'
options['renumber'] = 1
options['pedfile'] = 'toller.ped'
#options['pedfile'] = 'jbc.ped'
options['pedformat'] = 'asdgb'
options['pedname'] = 'My Pedigree'
example = pyp_newclasses.NewPedigree(options)
example.load()
##example.metadata.printme()
#my_b = pyp_nrm.inbreeding(example.pedigree,filetag='test')
#print my_b

#example.save(filename='toller_original_oid.ped',outformat='l',idformat='o')
#example.save(filename='toller_original_rid.ped',outformat='o',idformat='r')

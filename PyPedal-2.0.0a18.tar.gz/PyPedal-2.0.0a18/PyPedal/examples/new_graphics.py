#!/usr/bin/python

###############################################################################
# NAME: new_graphics.py
# VERSION: 2.0.0a17 (06MAY2005)
# AUTHOR: John B. Cole, PhD (jcole@aipl.arsusda.gov)
# LICENSE: LGPL
###############################################################################

try:
    import psyco
    psyco.full()
except ImportError:
    pass

import pyp_demog, pyp_graphics, pyp_newclasses, pyp_nrm, pyp_metrics
from pyp_utils import pyp_nice_time

if __name__ == '__main__':

    print 'Starting pypedal.py at %s' % (pyp_nice_time())

    example = pyp_newclasses.NewAMatrix({})
    example.load('boichard2_pedigree.bin')
    
    if example.kw['messages'] == 'verbose':
        print '[INFO]: Calling pyp_graphics.rmuller_spy_matrix_pil() at %s' % (pyp_nice_time())
    pyp_graphics.rmuller_spy_matrix_pil(example.nrm,fname='tolled_pedigree_sparsity.png',cutoff=0.01,do_outline=0,
        height=example.nrm.shape[0],width=example.nrm.shape[0])
    
    if example.kw['messages'] == 'verbose':
        print '[INFO]: Calling pyp_graphics.rmuller_pcolor_matrix_pil() at %s' % (pyp_nice_time())
    pyp_graphics.rmuller_pcolor_matrix_pil(example.nrm,fname='tolled_pedigree_colored.png',do_outline=0,
        height=example.nrm.shape[0],width=example.nrm.shape[0])
        
    print 'Stopping pypedal.py at %s' % (pyp_nice_time())

#     options = {}
#     options['renumber'] = 0
#     options['pedfile'] = 'boichard2.ped'
#     options['pedformat'] = 'asdg'
#     options['messages'] = 'verbose'
#     example = pyp_newclasses.NewPedigree(options)
#     example.load()
#     example_nrm = pyp_newclasses.NewAMatrix({})
#     example_nrm.fast_a_matrix(example.pedigree)
#     pyp_graphics.rmuller_pcolor_matrix_pil(example_nrm.nrm,fname='boichard_pedigree_colored_rmuller.png',do_outline=0)
#     pyp_graphics.pcolor_matrix_pylab(example_nrm.nrm,fname='boichard_pedigree_colored_pylab')
#     pyp_graphics.spy_matrix_pylab(example_nrm.nrm,fname='boichard_pedigree_sparsity_pylab')
        
#     if example.kw['messages'] == 'verbose':
#         print '[INFO]: Calling pyp_graphics.draw_pedigree() at %s' % (pyp_nice_time())
#     pyp_graphics.draw_pedigree(example.pedigree,gfilename='new_graphics_pedigree',gtitle='Sample pedigree for new_graphics example',gformat='jpg',gsize='f')

#     if example.kw['messages'] == 'verbose':
#         print '[INFO]: Calling pyp_graphics.plot_founders_by_year() at %s' % (pyp_nice_time())
#     pyp_graphics.plot_founders_by_year(example,gfilename='new_graphics',gtitle='Number of founders within each birthyear')
#     
#     if example.kw['messages'] == 'verbose':
#         print '[INFO]: Calling pyp_graphics.plot_pct_founders_by_year() at %s' % (pyp_nice_time())
#     pyp_graphics.plot_founders_pct_by_year(example,gfilename='new_graphics_founder_pct',gtitle='Percentage of founders within each birthyear')
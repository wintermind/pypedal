#!/usr/bin/python

###############################################################################
# NAME: new_classes.py
# VERSION: 2.0.0a9 (04MAR2005)
# AUTHOR: John B. Cole, PhD (jcole@aipl.arsusda.gov)
# LICENSE: LGPL
###############################################################################

import pyp_graphics
import pyp_newclasses
import pyp_nrm
import time

options = {}
options['pedfile'] = 'boichard2.ped'
options['pedformat'] = 'asdg'
options['pedname'] = 'Boichard 2 Pedigree'
options['messages'] = 'verbose'
options['renumber'] = 1
options['counter'] = 5

if __name__ == '__main__':

    print 'Starting pypedal.py at %s' % time.asctime(time.localtime(time.time()))
    
    example = pyp_newclasses.NewPedigree(options)
    example.load()
    
    if example.kw['messages'] == 'verbose':
        print '[INFO]: Forming numerator relationship matrix at %s' % (time.asctime(time.localtime(time.time())))
    
    my_a = pyp_nrm.fast_a_matrix_r(example.pedigree)
    
    if example.kw['messages'] == 'verbose':
        print '[INFO]: Visualizing NRM sparsity at %s' % (time.asctime(time.localtime(time.time())))

    pyp_graphics.rmuller_spy_matrix_pil(my_a,fname='boichard2_spy.png')
    
    if example.kw['messages'] == 'verbose':
        print '[INFO]: Visualizing NRM in pseudocolor at %s' % (time.asctime(time.localtime(time.time())))

    pyp_graphics.rmuller_pcolor_matrix_pil(my_a,fname='boichard2_pcolor.png')

    print 'Stopping pypedal.py at %s' % time.asctime(time.localtime(time.time()))
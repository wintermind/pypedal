#!/usr/bin/python

###############################################################################
# NAME: example_renum.py
# VERSION: 2.0.0a7 (26MAY2004)
# AUTHOR: John B. Cole, PhD (jcole@aipl.arsusda.gov)
# LICENSE: LGPL
###############################################################################

from pyp_classes import *
from pyp_io import *
from pyp_metrics import *
from pyp_nrm import *
from pyp_utils import *

if __name__=='__main__':

	print 'Starting pypedal.py at %s' % asctime(localtime(time()))

	print '\tLoading pedigree at %s' % asctime(localtime(time()))
	example,example_meta = load_pedigree('example_renum.ped',filetag='example_renum',sepchar=' ',debug=0,io='yes',renum=1,outformat='0',name='Example Pedigree',alleles=1)
	for animal in example:
		animal.printme()
	example_meta.printme()

	print 'Stopping pypedal.py at %s' % asctime(localtime(time()))

#!/usr/bin/python

###############################################################################
# NAME: onesided.py
# VERSION: 2.0.0ay (20JULY2004)
# AUTHOR: John B. Cole, PhD (jcole@aipl.arsusda.gov)
# LICENSE: LGPL
###############################################################################

from pyp_classes import *
from pyp_io import *
from pyp_metrics import *
from pyp_nrm import *
from pyp_utils import *

if __name__=='__main__':

	print 'Starting pypedal.py at %s' % asctime(localtime(time()))

	print '\tPreprocessing pedigree at %s' % asctime(localtime(time()))
        # example = preprocess('onesided.ped',sepchar=' ')
	example, example_meta = load_pedigree('onesided.ped',filetag='onesided')
	example_meta.printme()
	#for _e in example:
	#	_e.printme()
        #print '\tCalling recurse_pedigree_onesided() at %s' % asctime(localtime(time()))
	#_sireped = []
	#_sireped = recurse_pedigree_onesided(example,31,_sireped,'s')
	#for _s in _sireped:
	#	print _s.animalID
	#print '-'*80
	#_damped = []
	#_damped = recurse_pedigree_onesided(example,31,_damped,'d')
	#for _d in _damped:
	#	print _d.animalID
	#print '-'*80
	#print 'Zero-generation pedigree'
	#_shortped = []
	#_shortped = recurse_pedigree_n(example,31,_shortped,0)
	#for _s in _shortped:
	#	print _s.animalID				
	#print '-'*80
	#print 'One-generation pedigree'
	#_shortped = []
	#_shortped = recurse_pedigree_n(example,31,_shortped,1)
	#for _s in _shortped:
        #        print _s.animalID
	#print '-'*80
	#print 'Two-generation pedigree'
        #_shortped = []
        #_shortped = recurse_pedigree_n(example,31,_shortped,2)
	#for _s in _shortped:
        #        print _s.animalID
	#print '-'*80
	#print 'Three-generation pedigree'
        #_shortped = []
        #_shortped = recurse_pedigree_n(example,31,_shortped,3)
        #for _s in _shortped:
        #        print _s.animalID
        #print '-'*80
        #print 'Four-generation pedigree'
        #_shortped = []
        #_shortped = recurse_pedigree_n(example,31,_shortped,4)
        #for _s in _shortped:
        #        print _s.animalID
	print '-'*80
	print 'Computing 3-generation pedigree completeness...'
        pedigree_completeness(example,'example',3)

	#for _e in example:
        #       print _e.pedcomp

	print 'Stopping pypedal.py at %s' % asctime(localtime(time()))

#!/usr/bin/python

###############################################################################
# NAME: new_lacy.py
# VERSION: 2.0.0a9 (29MAR2005)
# AUTHOR: John B. Cole, PhD (jcole@aipl.arsusda.gov)
# LICENSE: LGPL
###############################################################################

import pyp_newclasses
import pyp_nrm
import pyp_metrics
from pyp_utils import pyp_nice_time
import time

options = {}
options['messages'] = 'verbose'
options['renumber'] = 0
options['counter'] = 5

if __name__ == '__main__':

    print 'Starting pypedal.py at %s' % (pyp_nice_time())
    
# Example taken from Lacy (1989), Appendix A. 
    options['pedfile'] = 'new_lacy.ped'
    options['pedformat'] = 'asd'
    options['pedname'] = 'Lacy Pedigree'
    example = pyp_newclasses.NewPedigree(options)
    example.load()
    if example.kw['messages'] == 'verbose':
        print '[INFO]: Calling pyp_metrics.effective_founders_lacy at %s' % (pyp_nice_time())
    pyp_metrics.effective_founders_lacy(example)

    print '='*80

# Example taken from Boichard et al. (1997), Figure 2 / Table II.
    options['pedfile'] = 'boichard2a.ped'
    options['pedname'] = 'Boichard Pedigree (Family A only)'
    options['pedformat'] = 'asdg'
    example2a = pyp_newclasses.NewPedigree(options)
    example2a.load()
    if example2a.kw['messages'] == 'verbose':
        print '[INFO]: Calling pyp_metrics.effective_founders_lacy at %s' % (pyp_nice_time())
    pyp_metrics.effective_founders_lacy(example2a)
    if example2a.kw['messages'] == 'verbose':
        print 'Calling a_effective_founders_boichard() at %s' % (pyp_nice_time())
    pyp_metrics.a_effective_founders_boichard(example2a.pedigree,filetag='example2a')
    if example2a.kw['messages'] == 'verbose':
        print 'Calling a_effective_ancestors() at %s' % (pyp_nice_time())
    pyp_metrics.a_effective_ancestors(example2a.pedigree,filetag='example2a')

    print '='*80
    
# Example taken from Boichard et al. (1997), Figure 2 / Table II.
    options['pedfile'] = 'boichard2b.ped'
    options['pedname'] = 'Boichard Pedigree (Family B only)'
    options['pedformat'] = 'asdg'
    example2b = pyp_newclasses.NewPedigree(options)
    example2b.load()
    if example2b.kw['messages'] == 'verbose':
        print '[INFO]: Calling pyp_metrics.effective_founders_lacy at %s' % (pyp_nice_time())
    pyp_metrics.effective_founders_lacy(example2b)
    if example2b.kw['messages'] == 'verbose':
        print 'Calling a_effective_founders_boichard() at %s' % (pyp_nice_time())
    pyp_metrics.a_effective_founders_boichard(example2b.pedigree,filetag='example2b')
    if example2b.kw['messages'] == 'verbose':
        print 'Calling a_effective_ancestors() at %s' % (pyp_nice_time())
    pyp_metrics.a_effective_ancestors(example2b.pedigree,filetag='example2b')
    
    print '='*80

# Example taken from Boichard et al. (1997), Figure 2 / Table II.
    options['pedfile'] = 'boichard2.ped'
    options['pedname'] = 'Boichard Pedigree'
    options['pedformat'] = 'asdg'
    example2 = pyp_newclasses.NewPedigree(options)
    example2.load()
    if example2.kw['messages'] == 'verbose':
        print '[INFO]: Calling pyp_metrics.effective_founders_lacy at %s' % (pyp_nice_time())
    pyp_metrics.effective_founders_lacy(example2)
    if example2.kw['messages'] == 'verbose':
        print 'Calling a_effective_founders_boichard() at %s' % (pyp_nice_time())
    pyp_metrics.a_effective_founders_boichard(example2.pedigree,filetag='example2')
    if example2.kw['messages'] == 'verbose':
        print 'Calling a_effective_ancestors() at %s' % (pyp_nice_time())
    pyp_metrics.a_effective_ancestors(example2.pedigree,filetag='example2')

# Example taken from Boichard et al. (1997), Figure 1 / Table I.
    options['pedfile'] = 'boichard1.ped'
    options['pedname'] = 'Boichard Pedigree'
    options['pedformat'] = 'asdg'
    example1 = pyp_newclasses.NewPedigree(options)
    example1.load()
    if example1.kw['messages'] == 'verbose':
        print '[INFO]: Calling pyp_metrics.effective_founders_lacy at %s' % (pyp_nice_time())
    pyp_metrics.effective_founders_lacy(example1)
    if example1.kw['messages'] == 'verbose':
        print 'Calling a_effective_founders_boichard() at %s' % (pyp_nice_time())
    pyp_metrics.a_effective_founders_boichard(example1.pedigree,filetag='example1')
    if example1.kw['messages'] == 'verbose':
        print 'Calling a_effective_ancestors() at %s' % (pyp_nice_time())
    pyp_metrics.a_effective_ancestors(example1.pedigree,filetag='example1')
            
    print 'Stopping pypedal.py at %s' % (pyp_nice_time())
#!/usr/bin/python

###############################################################################
# NAME: new_amatrix.py
# VERSION: 2.0.0a16 (03MAY2005)
# AUTHOR: John B. Cole, PhD (jcole@aipl.arsusda.gov)
# LICENSE: LGPL
###############################################################################

import pyp_demog, pyp_graphics, pyp_newclasses, pyp_nrm, pyp_metrics
from pyp_utils import pyp_nice_time
import numarray,time

options = {}
options['messages'] = 'verbose'
options['renumber'] = 1
options['counter'] = 5

if __name__ == '__main__':

    print 'Starting pypedal.py at %s' % (pyp_nice_time())

    options['pedfile'] = 'toller.ped'
    options['pedname'] = 'Toller Pedigree'
    options['pedformat'] = 'asdgb'
    example = pyp_newclasses.NewPedigree(options)
    example.load()

    amatrix = pyp_newclasses.NewAMatrix({})
    amatrix.form_a_matrix(example.pedigree)
    print amatrix.nrm
    amatrix.info()
    amatrix.save('boichard2_pedigree.bin')

    amatrix2 = pyp_newclasses.NewAMatrix({})
    amatrix2.load('boichard2_pedigree.bin')
    print amatrix2.nrm
    amatrix2.info()

#     if example.kw['messages'] == 'verbose':
#         print '[INFO]: Calling pyp_graphics.draw_pedigree() at %s' % (pyp_nice_time())
#!/usr/bin/python

###############################################################################
# NAME: new_graphics.py
# VERSION: 2.0.0a11 (15APRIL2005)
# AUTHOR: John B. Cole, PhD (jcole@aipl.arsusda.gov)
# LICENSE: LGPL
###############################################################################

import pyp_demog, pyp_graphics, pyp_newclasses, pyp_nrm, pyp_metrics
from pyp_utils import pyp_nice_time
import time

options = {}
options['messages'] = 'verbose'
options['renumber'] = 1
options['pedfile'] = 'new_renumbering.ped'
options['pedformat'] = 'asdgb'
options['pedname'] = 'My Pedigree'

if __name__ == '__main__':

    example = pyp_newclasses.NewPedigree(options)
    example.load() 

    print '-'*80
    print 'INFO: Pedigree ID map: %s' % (example.idmap)
    print '-'*80
    print 'INFO: Pedigree ID reverse map: %s' % (example.backmap)
    print '-'*80
    myinbr = pyp_nrm.inbreeding(example.pedigree,filetag=example.kw['filetag'])
    print 'INFO: Coefficients of inbreeding: %s' % (myinbr)
#     print '-'*80
#     for _b in example.backmap.keys():
#         print 'Orig: %s\tRenum: %s\tf_a: %s' % (example.backmap[_b],_b,example.pedigree[int(_b)-1].fa)
        
    pyp_graphics.draw_pedigree(example.pedigree,gfilename='toller',gtitle='Toller pedigree')
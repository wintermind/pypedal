#!/usr/bin/python

###############################################################################
# NAME: new_ids.py
# VERSION: 2.0.0a16 (04MAY2005)
# AUTHOR: John B. Cole, PhD (jcole@aipl.arsusda.gov)
# LICENSE: LGPL
###############################################################################

import pyp_newclasses
import pyp_nrm
import pyp_metrics
from pyp_utils import pyp_nice_time

options = {}
options['messages'] = 'verbose'
options['renumber'] = 0
options['counter'] = 5
options['missing_parent'] = 'animal0'
options['sepchar'] = '\t'

if __name__ == '__main__':

    print 'Starting pypedal.py at %s' % (pyp_nice_time())
    
    # Example taken from Lacy (1989), Appendix A. 
    options['pedfile'] = 'new_ids2.ped'
    options['pedformat'] = 'ASD'
    options['pedname'] = 'Boichard Pedigree'
    example = pyp_newclasses.NewPedigree(options)
    example.load()
    
    for _p in example.pedigree:
        _p.printme()